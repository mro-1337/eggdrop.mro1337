==========================================================================
  EGGDROP CALCULATOR  -  calc.tcl v1.0
  Calculator & unit converter for Eggdrop IRC bots
==========================================================================

WHAT IT DOES
------------
  calc 1+1                    ->  1+1 = 2
  calc sqrt(2)*pi             ->  sqrt(2)*pi = 4.44288293816
  calc 100 inches in mm       ->  100 in = 2540 mm
  calc 98.6 F to C            ->  98.6 F = 37 C
  calc 255 in hex             ->  255 = 0xFF
  calc help                   ->  instructions for every command

  - Full math: + - * / ^ % !, parentheses, 50+ functions (trig, logs,
    roots, rounding, factorial, nCr, gcd, random...), constants, and
    percentages ("calc 15% of 80").
  - Exact whole-number math, even for huge numbers (calc 2^200, calc 100!).
  - 184 units in 18 categories: length, area, volume, mass, time, speed,
    acceleration, temperature, pressure, energy, power, force, torque,
    data storage, data rate, angle, frequency and fuel economy.
  - Works in channels, in private message, and through an IRC <-> Telegram
    bridge (it reads the "<name>" prefix and answers the person by name).
  - Safe: what users type is never run as Tcl code.


FILES IN THIS PACKAGE
---------------------
  calc.tcl                     The script - this is the only file the bot needs
  README.txt                   This file: install, settings, troubleshooting
  COMMANDS.txt                 Every command with examples (for users)
  UNITS.txt                    Every unit the converter knows
  ERG.BOT.calc-commands.html   Command reference web page


REQUIREMENTS
------------
  - Eggdrop 1.8, 1.9 or 1.10
  - Tcl 8.5 or newer, including 8.6.5 (tested on 8.6.14)
  - No other scripts or packages needed


INSTALL
-------
  1. Copy calc.tcl into your bot's scripts/ directory.

  2. Add this line to the END of your eggdrop.conf:

        source scripts/calc.tcl

  3. Load it. In the partyline (DCC chat with the bot) type:

        .rehash

     or restart the bot. You should see in the log:

        calc.tcl loaded - type 'calc help' in a channel

  4. Test it in a channel the bot is in:

        calc 2+2

  UPGRADING: copy the new calc.tcl over the old one and .rehash.
  Old command bindings from earlier versions are removed automatically.


SETTINGS
--------
  The settings are at the top of calc.tcl, in the "array set cfg" block.
  Change a value, save, and .rehash.

  triggers   {calc !calc}
             Words that start a command. Add or remove as you like,
             e.g. {calc !calc .calc}

  cooldown   2
             Seconds a user must wait between commands. 0 turns it off.
             Telegram users each get their own cooldown, even though they
             all come through the same bridge.

  help_via   notice
             "notice"  - help is sent privately to the user (recommended)
             "channel" - help is posted in the channel
             Telegram users always get help in the channel, because a
             notice to the bridge would never reach them.

  anywhere   1
             1 - also answer when "calc" is in the middle of a line:
                 "hey can you calc 5 kg to lb for me"
                 In this mode the bot only answers if the calculation
                 works, so normal chat ("i'll calc it later") is ignored.
             0 - only answer when "calc" is the first word
                 (after a Telegram "<name>" prefix).

  maxlen     350
             Longest input accepted, in characters.

  maxdigits  200
             Whole numbers longer than this are shown in scientific
             notation with a digit count, e.g. 1000! = 4.0238726e+2567 (2568 digits)

  precision  12
             Significant digits shown for decimal results.


TELEGRAM / BRIDGE SUPPORT
-------------------------
  A bridge relays Telegram messages under one IRC nick (for example "_")
  with the real sender's name in front:

        <_> <mro1337> calc 2*2
        <erg> mro1337: 2*2 = 4

  The bot strips the <name> prefix (including any colour codes the bridge
  adds), answers the real person by name, and gives each bridged user their
  own cooldown and their own "ans" value. No setup is needed.


TROUBLESHOOTING
---------------
  Nothing happens when I type "calc 2+2"
    - Make sure "source scripts/calc.tcl" is in eggdrop.conf and you
      did .rehash. Check the partyline for the "calc.tcl loaded" line.
    - Wait 2 seconds between commands (the cooldown).
    - Another script may be using the same trigger word.

  Error: bad class "entier"
    - You have an old copy of calc.tcl. This version works on Tcl 8.6.5.

  The bot answers too often in normal chat
    - Set anywhere to 0.

  "Error: unknown unit"
    - Type "calc help units" to see the categories, then
      "calc help units <category>" for the unit names.

  "Error: can't convert Mass / weight (kg) to Length (m)"
    - Units must be the same kind. Converting volume to weight (cups to
      grams) needs the density of the ingredient, so it isn't possible.


NOT INCLUDED
------------
  - Currency conversion (rates change daily and need an online source)
  - Cooking volume <-> weight conversions (depend on the ingredient)
