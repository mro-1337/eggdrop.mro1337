###############################################################################
#  calc.tcl  -  Calculator & unit converter for Eggdrop
#
#  Usage in channel (or private message to the bot):
#     calc 1+1                     -> 2
#     calc sqrt(2)*pi              -> 4.44288293816
#     calc 100 inches in mm        -> 100 in = 2540 mm
#     calc 98.6 F to C             -> 98.6 F = 37 C
#     calc 255 in hex              -> 255 = 0xFF
#     calc help                    -> instructions (sent by notice)
#
#  Install:
#     1. Copy this file to your eggdrop's scripts/ directory
#     2. Add this line to the end of eggdrop.conf:   source scripts/calc.tcl
#     3. .rehash (or restart) the bot
#
#  Security: user input is NEVER passed to Tcl's expr/eval. Expressions are
#  parsed by a small built-in parser, so nobody can run Tcl commands through it.
#
#  Requires Tcl 8.5 or newer (Eggdrop 1.8 / 1.9 / 1.10 are fine).
###############################################################################

namespace eval ::calc {

    # ---------------------------- settings ---------------------------------
    variable cfg
    array set cfg {
        triggers    {calc !calc}
        cooldown    2
        help_via    notice
        maxlen      350
        maxdigits   200
        precision   12
        anywhere    1
    }
    # anywhere   - 1 = find "calc" anywhere in a line, e.g. "<mro1337> calc 2*2"
    #              from an IRC<->Telegram bridge, or "hey bot calc 5 kg to lb".
    #              When calc is NOT the first word, errors are not shown, so
    #              ordinary chat that happens to contain "calc" isn't answered.
    #              0 = only when calc is the first word (after a <name> prefix).
    # triggers   - words that start a calculation (first word of the line)
    # cooldown   - seconds a user must wait between commands (0 = off)
    # help_via   - "notice" sends help privately to the user,
    #              "channel" posts help in the channel
    # maxlen     - maximum length of input accepted
    # maxdigits  - integers longer than this are shown in scientific notation
    # precision  - significant digits shown for decimal results

    variable U;     array set U {}      ;# unit id -> {cat sym name kind factor offset}
    variable A;     array set A {}      ;# alias (exact case) -> unit id
    variable LA;    array set LA {}     ;# alias (lower case) -> unit id
    variable CATS;  array set CATS {}   ;# category -> list of unit ids
    variable CATNAME; array set CATNAME {}
    variable CATORDER {}
    variable UAL;   array set UAL {}    ;# unit id -> list of aliases
    variable ANS;   array set ANS {}    ;# nick -> last result
    variable LAST;  array set LAST {}   ;# uhost -> time of last command
    variable curcat ""
    variable T {}
    variable P 0
    variable D 0
}

###############################################################################
#  Unit table
###############################################################################

proc ::calc::cat {key title} {
    variable CATORDER; variable CATNAME; variable CATS; variable curcat
    if {$key ni $CATORDER} { lappend CATORDER $key }
    set CATNAME($key) $title
    if {![info exists CATS($key)]} { set CATS($key) {} }
    set curcat $key
}

# u sym name factor ?aliases? ?kind? ?offset?
#   kind lin : base = value * factor + offset
#   kind inv : base = factor / value          (e.g. L/100km)
proc ::calc::u {sym name factor {aliases {}} {kind lin} {offset 0}} {
    variable U; variable CATS; variable curcat; variable UAL
    set id "$curcat:$sym"
    set f [expr "double($factor)"]
    set o [expr "double($offset)"]
    set U($id) [list $curcat $sym $name $kind $f $o]
    lappend CATS($curcat) $id
    set al [concat [list $sym $name] $aliases]
    set UAL($id) $al
    foreach a $al { ::calc::reg $a $id }
}

proc ::calc::reg {a id} {
    variable A; variable LA
    if {![info exists A($a)]} { set A($a) $id }
    set la [string tolower $a]
    if {![info exists LA($la)]} { set LA($la) $id }
}

# Build square / cubic units from a length unit
proc ::calc::derive {lensym} {
    variable U; variable UAL; variable CATS; variable curcat
    set lid "length:$lensym"
    set f [lindex $U($lid) 4]
    set name [lindex $U($lid) 2]
    foreach {c pfx pw word} {area sq 2 square volume cu 3 cubic} {
        set id "$c:$pfx $lensym"
        set U($id) [list $c "$pfx $lensym" "$word $name" lin [expr {$f ** $pw}] 0.0]
        lappend CATS($c) $id
        set al [list "$pfx $lensym" "$word $name"]
        foreach a $UAL($lid) {
            if {$a in {' \"}} continue
            lappend al "$pfx $a" "$a$pw"
        }
        set UAL($id) $al
        foreach a $al { ::calc::reg $a $id }
    }
}

namespace eval ::calc {
    set mu \u00b5 ;# micro sign
    set dg \u00b0 ;# degree sign

    # ------------------------------ LENGTH (base: metre)
    cat length "Length"
    u pm  picometer  1e-12   {picometre}
    u nm  nanometer  1e-9    {nanometre}
    u um  micrometer 1e-6    [list ${mu}m micrometre micron]
    u mm  millimeter 1e-3    {millimetre}
    u cm  centimeter 1e-2    {centimetre}
    u dm  decimeter  1e-1    {decimetre}
    u m   meter      1       {metre}
    u km  kilometer  1000    {kilometre klick}
    u in  inch       0.0254  {\"}
    u ft  foot       0.3048  {feet '}
    u yd  yard       0.9144  {}
    u mi  mile       1609.344 {}
    u nmi "nautical mile" 1852 {}
    u angstrom angstrom 1e-10 [list \u00c5]
    u mil mil        2.54e-5 {thou}
    u point point    0.0254/72 {}
    u hand hand      0.1016  {}
    u fathom fathom  1.8288  {}
    u rod rod        5.0292  {}
    u chain chain    20.1168 {}
    u furlong furlong 201.168 {}
    u league league  4828.032 {}
    u au "astronomical unit" 149597870700 {}
    u ly "light year" 9460730472580800 {lightyear light-year}
    u pc parsec      3.0856775814913673e16 {}

    # ------------------------------ AREA (base: square metre)
    cat area "Area"
    foreach l {mm cm m km in ft yd mi} { derive $l }
    u ha hectare     1e4     {}
    u are are        100     {}
    u acre acre      4046.8564224 {ac}

    # ------------------------------ VOLUME (base: cubic metre)
    cat volume "Volume"
    u ml milliliter  1e-6    {mL millilitre cc}
    u cl centiliter  1e-5    {cL centilitre}
    u dl deciliter   1e-4    {dL decilitre}
    u l  liter       1e-3    {L litre ltr}
    u tsp teaspoon   4.92892159375e-6 {}
    u tbsp tablespoon 1.478676478125e-5 {}
    u "fl oz" "fluid ounce" 2.95735295625e-5 {floz "us fl oz" "us fluid ounce"}
    u cup cup        2.365882365e-4 {"us cup"}
    u pt pint        4.73176473e-4 {"us pint"}
    u qt quart       9.46352946e-4 {"us quart"}
    u gal gallon     3.785411784e-3 {"us gallon" "us gal"}
    u bbl barrel     0.158987294928 {"oil barrel"}
    u "imp fl oz" "imperial fluid ounce" 2.84130625e-5 {"uk fl oz" "uk fluid ounce"}
    u "imp pt" "imperial pint" 5.6826125e-4 {"uk pint" "imp pint"}
    u "imp qt" "imperial quart" 1.1365225e-3 {"uk quart" "imp quart"}
    u "imp gal" "imperial gallon" 4.54609e-3 {"uk gallon" "imp gallon" "uk gal"}
    # (cubic units like "cu ft" were already created by derive in the AREA section)

    # ------------------------------ MASS (base: kilogram)
    cat mass "Mass / weight"
    u ug microgram   1e-9    [list ${mu}g mcg]
    u mg milligram   1e-6    {}
    u g  gram        1e-3    {gramme}
    u kg kilogram    1       {kilo kilogramme}
    u t  tonne       1000    {"metric ton"}
    u ct carat       2e-4    {}
    u gr grain       6.479891e-5 {}
    u oz ounce       0.028349523125 {}
    u ozt "troy ounce" 0.0311034768 {"troy oz"}
    u lb pound       0.45359237 {lbs}
    u st stone       6.35029318 {}
    u ton "short ton" 907.18474 {"us ton"}
    u "long ton" "long ton" 1016.0469088 {"uk ton" "imperial ton"}
    u slug slug      14.59390294 {}
    u amu "atomic mass unit" 1.66053906660e-27 {u dalton Da}

    # ------------------------------ TIME (base: second)
    cat time "Time"
    u ns nanosecond  1e-9    {}
    u us microsecond 1e-6    [list ${mu}s]
    u ms millisecond 1e-3    {}
    u s  second      1       {sec}
    u min minute     60      {mins}
    u h  hour        3600    {hr hrs}
    u d  day         86400   {}
    u wk week        604800  {}
    u fortnight fortnight 1209600 {}
    u mo month       2629746 {}
    u yr year        31556952 {y}
    u decade decade  315569520 {}
    u century century 3155695200 {centuries}
    u millennium millennium 31556952000 {millennia}

    # ------------------------------ SPEED (base: metre/second)
    cat speed "Speed"
    u m/s "meter/second" 1   {mps "metre/second"}
    u km/h "kilometer/hour" 1/3.6 {kph kmh kmph km/hr km/hour "kilometre/hour"}
    u mph "mile/hour" 0.44704 {mi/h mi/hr mile/hr}
    u ft/s "foot/second" 0.3048 {fps feet/second ft/sec}
    u kn knot        1852/3600.0 {kt kts}
    u mach mach      340.29  {}
    u lightspeed "speed of light" 299792458 {}

    # ------------------------------ ACCELERATION (base: m/s^2)
    cat accel "Acceleration"
    u m/s2 "meter/second2" 1 {"meter/second/second" "metre/second2"}
    u ft/s2 "foot/second2" 0.3048 {"feet/second2"}
    u gn "standard gravity" 9.80665 {g-force gee g0}

    # ------------------------------ TEMPERATURE (base: kelvin)
    cat temp "Temperature"
    u C celsius      1       [list c ${dg}C ${dg}c degc "deg c" "degree c" "degree celsius" centigrade] lin 273.15
    u F fahrenheit   5/9.0   [list f ${dg}F ${dg}f degf "deg f" "degree f" "degree fahrenheit"] lin 459.67*5/9.0
    u K kelvin       1       {k}
    u R rankine      5/9.0   [list r ${dg}R ${dg}r degr "degree rankine"]

    # ------------------------------ PRESSURE (base: pascal)
    cat pressure "Pressure"
    u Pa pascal      1       {}
    u hPa hectopascal 100    {}
    u kPa kilopascal 1000    {}
    u MPa megapascal 1e6     {}
    u bar bar        1e5     {}
    u mbar millibar  100     {}
    u atm atmosphere 101325  {}
    u psi psi        6894.757293168361 {lbf/in2 "pound/square inch"}
    u torr torr      101325/760.0 {}
    u mmHg "millimeter of mercury" 133.322387415 {}
    u inHg "inch of mercury" 3386.389 {}

    # ------------------------------ ENERGY (base: joule)
    cat energy "Energy"
    u J  joule       1       {}
    u kJ kilojoule   1000    {}
    u MJ megajoule   1e6     {}
    u cal calorie    4.184   {}
    u kcal kilocalorie 4184  {Cal "food calorie"}
    u Wh "watt hour" 3600    {}
    u kWh "kilowatt hour" 3.6e6 {}
    u eV "electron volt" 1.602176634e-19 {}
    u BTU "british thermal unit" 1055.05585262 {}
    u therm therm    1.05505585262e8 {}
    u ft-lbf "foot-pound" 1.3558179483314004 {ft-lb ftlb}
    u erg erg        1e-7    {}
    u "ton TNT" "ton of tnt" 4.184e9 {tnt}

    # ------------------------------ POWER (base: watt)
    cat power "Power"
    u W  watt        1       {}
    u MW megawatt    1e6     {}
    u mW milliwatt   1e-3    {}
    u kW kilowatt    1000    {}
    u GW gigawatt    1e9     {}
    u hp horsepower  745.69987158227022 {bhp}
    u PS "metric horsepower" 735.49875 {cv}
    u BTU/h "BTU/hour" 0.29307107017 {btu/hr}

    # ------------------------------ FORCE (base: newton)
    cat force "Force"
    u N  newton      1       {}
    u kN kilonewton  1000    {}
    u dyn dyne       1e-5    {}
    u lbf "pound-force" 4.4482216152605 {"pound force"}
    u kgf "kilogram-force" 9.80665 {kp}

    # ------------------------------ TORQUE (base: newton metre)
    cat torque "Torque"
    u N*m "newton meter" 1   {Nm N-m "newton metre" newton-meter}
    u lb-ft "pound-foot" 1.3558179483314004 {lbf-ft lbft}
    u lb-in "pound-inch" 0.1129848290276167 {lbf-in}

    # ------------------------------ DATA (base: byte)
    cat data "Data storage"
    u B  byte        1       {}
    u KB kilobyte    1e3     {kB}
    u MB megabyte    1e6     {}
    u GB gigabyte    1e9     {}
    u TB terabyte    1e12    {}
    u PB petabyte    1e15    {}
    u KiB kibibyte   1024    {}
    u MiB mebibyte   1048576 {}
    u GiB gibibyte   1073741824 {}
    u TiB tebibyte   1099511627776 {}
    u b  bit         0.125   {}
    u Kb kilobit     125     {kbit}
    u Mb megabit     125000  {Mbit}
    u Gb gigabit     1.25e8  {Gbit}
    u Tb terabit     1.25e11 {Tbit}

    # ------------------------------ DATA RATE (base: bit/second)
    cat rate "Data rate"
    u MB/s "megabyte/second" 8e6 {MBps}
    u KB/s "kilobyte/second" 8e3 {KBps kB/s}
    u GB/s "gigabyte/second" 8e9 {GBps}
    u B/s "byte/second" 8 {Bps}
    u bps "bit/second" 1 {b/s bit/s}
    u kbps "kilobit/second" 1e3 {Kbps kb/s Kb/s}
    u Mbps "megabit/second" 1e6 {Mb/s}
    u Gbps "gigabit/second" 1e9 {Gb/s}

    # ------------------------------ ANGLE (base: radian)
    cat angle "Angle"
    u rad radian     1       {}
    u deg degree     0.017453292519943295 [list $dg]
    u grad gradian   0.015707963267948967 {gon}
    u arcmin arcminute 0.017453292519943295/60 {moa}
    u arcsec arcsecond 0.017453292519943295/3600 {}
    u mrad milliradian 1e-3 {}
    u turn turn      6.283185307179586 {rev revolution rotation}

    # ------------------------------ FREQUENCY (base: hertz)
    cat freq "Frequency"
    u Hz hertz       1       {}
    u kHz kilohertz  1e3     {}
    u MHz megahertz  1e6     {}
    u GHz gigahertz  1e9     {}
    u THz terahertz  1e12    {}
    u rpm "revolution/minute" 1/60.0 {}
    u bpm "beat/minute" 1/60.0 {}

    # ------------------------------ FUEL ECONOMY (base: km per litre)
    cat fuel "Fuel economy"
    u mpg "mile/gallon" 0.425143707 {"us mpg" mi/gal}
    u "mpg imp" "mile/imperial gallon" 0.354006189 {"uk mpg" mpg-imp "imperial mpg"}
    u km/L "kilometer/liter" 1 {kpl km/l "kilometre/litre"}
    u L/100km "liter/100 km" 100 {"l/100 km" "litre/100 km" "liter/100km" lp100km} inv

    unset mu dg
}

###############################################################################
#  Unit lookup
###############################################################################

proc ::calc::depl {s} {
    set out ""
    foreach tok [regexp -all -inline {[A-Za-z]+|[^A-Za-z]+} $s] {
        if {[regexp {^[A-Za-z]{3,}$} $tok]} {
            if {[regexp -nocase {(ch|sh|ss|x)es$} $tok]} {
                set tok [string range $tok 0 end-2]
            } elseif {[regexp -nocase {[^su]s$} $tok]} {
                set tok [string range $tok 0 end-1]
            }
        }
        append out $tok
    }
    return $out
}

proc ::calc::lookup {s} {
    variable A; variable LA
    set s [string map [list \u00b2 2 \u00b3 3 \u03bc \u00b5 \u00b7 *] $s]
    set s [string trim [regsub -all {\s+} $s " "]]
    if {$s eq ""} { return "" }
    set r $s
    regsub -all -nocase {\s+per\s+} $r "/" r
    regsub -all {\s*/\s*} $r "/" r
    regsub -all {([A-Za-z])\.} $r {\1} r
    regsub -all {\^([23])} $r {\1} r
    regsub -all -nocase {(^|\s)square\s+} $r {\1sq } r
    regsub -all -nocase {(^|\s)cubic\s+} $r {\1cu } r
    regsub -nocase {^(sq|cu)\s*(?=[a-z])} $r {\1 } r
    set r [string trim $r]
    foreach v [list $s $r [depl $s] [depl $r]] {
        if {[info exists A($v)]} { return $A($v) }
        set lv [string tolower $v]
        if {[info exists A($lv)]} { return $A($lv) }
        if {[info exists LA($lv)]} { return $LA($lv) }
    }
    return ""
}

###############################################################################
#  Expression parser (safe - never calls expr on user text)
###############################################################################

proc ::calc::tokenize {s} {
    set toks {}
    set i 0
    set n [string length $s]
    while {$i < $n} {
        set rest [string range $s $i end]
        if {[regexp {^\s+} $rest m]} {
            incr i [string length $m]; continue
        }
        if {[regexp {^0[xX][0-9a-fA-F]+|^0[bB][01]+|^0[oO][0-7]+} $rest m]} {
            lappend toks [list num [expr {$m + 0}]]
        } elseif {[regexp {^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?} $rest m]} {
            if {[regexp {^\d+$} $m]} {
                set v [regsub {^0+(?=\d)} $m ""]
                if {[string length $v] > 1000} { error "number too long" }
            } else {
                if {[catch {expr {double($m)}} v]} { error "number out of range: $m" }
            }
            lappend toks [list num $v]
        } elseif {[regexp {^[A-Za-z_][A-Za-z0-9_]*} $rest m]} {
            lappend toks [list id $m]
        } elseif {[string range $rest 0 1] eq "**"} {
            set m "**"
            lappend toks [list op ^]
        } else {
            set m [string index $rest 0]
            switch -- $m {
                + - - - * - / - % - ^ - ! { lappend toks [list op $m] }
                ( { lappend toks [list lp (] }
                ) { lappend toks [list rp )] }
                , { lappend toks [list comma ,] }
                default { error "unexpected character '$m'" }
            }
        }
        incr i [string length $m]
    }
    if {[llength $toks] > 400} { error "expression too long" }
    return $toks
}

proc ::calc::peek {} { variable T; variable P; return [lindex $T $P] }
proc ::calc::adv  {} { variable P; incr P }
proc ::calc::isop {t ops} { expr {[lindex $t 0] eq "op" && [lindex $t 1] in $ops} }

proc ::calc::pexpr {} {
    set v [pterm]
    while {1} {
        set t [peek]
        if {[isop $t {+ -}]} {
            adv
            set v [binop [lindex $t 1] $v [pterm]]
        } else break
    }
    return $v
}

proc ::calc::pterm {} {
    set v [punary]
    while {1} {
        set t [peek]
        lassign $t ty val
        if {[isop $t {* / %}]} {
            adv
            set v [binop $val $v [punary]]
        } elseif {$ty eq "id" && [string tolower $val] eq "mod"} {
            adv
            set v [binop % $v [punary]]
        } elseif {$ty in {num id lp}} {
            # implicit multiplication: 2pi, 3(4+5), 2 sqrt(9)
            set v [binop * $v [punary]]
        } else break
    }
    return $v
}

proc ::calc::punary {} {
    set t [peek]
    if {[isop $t -]} { adv; return [binop - 0 [punary]] }
    if {[isop $t +]} { adv; return [punary] }
    return [ppower]
}

proc ::calc::ppower {} {
    set b [ppostfix]
    if {[isop [peek] ^]} {
        adv
        return [binop ^ $b [punary]]
    }
    return $b
}

proc ::calc::ppostfix {} {
    set v [pprimary]
    while {[isop [peek] !]} { adv; set v [fn_fact $v] }
    return $v
}

proc ::calc::pprimary {} {
    variable D
    if {[incr D] > 60} { error "too deeply nested" }
    set t [peek]
    lassign $t ty val
    switch -- $ty {
        num { adv; set r $val }
        lp {
            adv
            set r [pexpr]
            if {[lindex [peek] 0] ne "rp"} { error "missing )" }
            adv
        }
        id {
            adv
            set fn [string tolower $val]
            if {[lindex [peek] 0] eq "lp"} {
                adv
                set argv {}
                if {[lindex [peek] 0] ne "rp"} {
                    while {1} {
                        lappend argv [pexpr]
                        if {[lindex [peek] 0] eq "comma"} { adv; continue }
                        break
                    }
                }
                if {[lindex [peek] 0] ne "rp"} { error "missing ) after $val(...)" }
                adv
                set r [callfn $fn $argv]
            } elseif {[isfn $fn]} {
                set r [callfn $fn [list [punary]]]
            } else {
                set r [constant $val]
            }
        }
        "" { error "expression ends unexpectedly" }
        default { error "unexpected '$val'" }
    }
    incr D -1
    return $r
}

###############################################################################
#  Arithmetic
###############################################################################

# whole number check (works on every Tcl 8.5/8.6 version, including big integers)
proc ::calc::isint {v} { regexp {^[-+]?[0-9]+$} $v }

proc ::calc::chk {v} {
    if {[string match -nocase *inf* $v] || [string match -nocase *nan* $v]} {
        error "result is undefined or too large"
    }
    return $v
}

proc ::calc::num {v} {
    # turn a whole double into an integer (for things like factorial, gcd)
    if {[isint $v]} { return $v }
    if {$v == floor($v) && abs($v) < 1e15} { return [expr {entier($v)}] }
    return ""
}

proc ::calc::binop {op a b} {
    switch -- $op {
        + { return [chk [expr {$a + $b}]] }
        - { return [chk [expr {$a - $b}]] }
        * {
            if {[isint $a] && [isint $b] && [string length $a] + [string length $b] > 3000} {
                error "result too large"
            }
            return [chk [expr {$a * $b}]]
        }
        / {
            if {$b == 0} { error "division by zero" }
            if {[isint $a] && [isint $b] && $a % $b == 0} { return [expr {$a / $b}] }
            return [chk [expr {double($a) / $b}]]
        }
        % {
            if {$b == 0} { error "division by zero" }
            if {[isint $a] && [isint $b]} { return [expr {$a % $b}] }
            return [chk [expr {fmod($a, $b)}]]
        }
        ^ {
            if {[isint $a] && [isint $b] && $b >= 0} {
                if {$a == 0 || $a == 1 || $b == 0} { return [expr {$a ** $b}] }
                if {$a == -1} { return [expr {$b % 2 ? -1 : 1}] }
                if {$b * log10(abs(double($a))) > 3000} { error "result too large" }
                return [expr {$a ** $b}]
            }
            if {$a == 0 && $b < 0} { error "division by zero" }
            if {$a < 0 && $b != floor($b)} { error "result is a complex number" }
            return [chk [expr {pow(double($a), double($b))}]]
        }
    }
    error "unknown operator $op"
}

###############################################################################
#  Functions and constants
###############################################################################

namespace eval ::calc {
    # name {minargs maxargs}  (-1 = unlimited)
    variable FN
    array set FN {
        sqrt {1 1} cbrt {1 1} root {2 2} abs {1 1} sign {1 1} sgn {1 1}
        exp {1 1} ln {1 1} log {1 2} log10 {1 1} log2 {1 1}
        sin {1 1} cos {1 1} tan {1 1} sec {1 1} csc {1 1} cot {1 1}
        asin {1 1} acos {1 1} atan {1 1} atan2 {2 2}
        sind {1 1} cosd {1 1} tand {1 1} asind {1 1} acosd {1 1} atand {1 1}
        sinh {1 1} cosh {1 1} tanh {1 1} asinh {1 1} acosh {1 1} atanh {1 1}
        floor {1 1} ceil {1 1} round {1 2} trunc {1 1} int {1 1} frac {1 1}
        min {1 -1} max {1 -1} sum {1 -1} avg {1 -1} mean {1 -1} median {1 -1}
        hypot {1 -1} pow {2 2} mod {2 2}
        fact {1 1} factorial {1 1} ncr {2 2} comb {2 2} choose {2 2}
        npr {2 2} perm {2 2} gcd {2 -1} lcm {2 -1}
        deg {1 1} rad {1 1} rand {0 2} isprime {1 1}
    }
    variable CONST
    array set CONST {
        pi    3.141592653589793
        tau   6.283185307179586
        e     2.718281828459045
        phi   1.618033988749895
        c     299792458.0
        g     9.80665
        G     6.6743e-11
        h     6.62607015e-34
        k     1.380649e-23
        NA    6.02214076e23
        R     8.314462618
        qe    1.602176634e-19
        me    9.1093837015e-31
        mp    1.67262192369e-27
        inf   ""
    }
    unset CONST(inf)
}

proc ::calc::isfn {name} { variable FN; info exists FN($name) }

proc ::calc::constant {name} {
    variable CONST; variable ANS; variable curnick
    if {[string tolower $name] eq "ans"} {
        set k [string tolower $curnick]
        if {[info exists ANS($k)]} { return $ANS($k) }
        error "no previous answer yet"
    }
    if {[info exists CONST($name)]} { return $CONST($name) }
    set l [string tolower $name]
    if {[info exists CONST($l)]} { return $CONST($l) }
    if {[lookup $name] ne ""} {
        error "'$name' is a unit - to convert use: calc <number> <unit> in <unit>"
    }
    error "unknown name '$name' (see: calc help)"
}

proc ::calc::clean {v} {
    # remove floating point noise like sin(pi) = 1.2e-16
    if {![isint $v] && abs($v) < 1e-14} { return 0.0 }
    return $v
}

proc ::calc::needint {v what} {
    set n [num $v]
    if {$n eq ""} { error "$what needs whole numbers" }
    return $n
}

proc ::calc::fn_fact {v} {
    set n [num $v]
    if {$n eq "" || $n < 0} { error "factorial needs a whole number 0 or greater" }
    if {$n > 3000} { error "factorial too large (max 3000!)" }
    set r 1
    for {set i 2} {$i <= $n} {incr i} { set r [expr {$r * $i}] }
    return $r
}

proc ::calc::callfn {fn argv} {
    variable FN
    if {![info exists FN($fn)]} { error "unknown function '$fn' (see: calc help functions)" }
    lassign $FN($fn) lo hi
    set n [llength $argv]
    if {$n < $lo || ($hi >= 0 && $n > $hi)} {
        if {$lo == $hi} { error "${fn}() takes $lo argument[expr {$lo == 1 ? {} : {s}}]" }
        error "${fn}() takes $lo to [expr {$hi < 0 ? {any number of} : $hi}] arguments"
    }
    lassign $argv x y
    set d2r 0.017453292519943295
    switch -- $fn {
        sqrt {
            if {$x < 0} { error "square root of a negative number" }
            if {[isint $x]} { set r [expr {isqrt($x)}]; if {$r * $r == $x} { return $r } }
            return [expr {sqrt(double($x))}]
        }
        cbrt {
            if {[isint $x]} {
                set r [expr {round(pow(abs(double($x)), 1.0/3))}]
                if {$x < 0} { set r [expr {-$r}] }
                if {$r * $r * $r == $x} { return $r }
            }
            set r [expr {pow(abs(double($x)), 1.0/3)}]
            return [expr {$x < 0 ? -$r : $r}]
        }
        root {
            if {$y == 0} { error "zeroth root is undefined" }
            if {$x < 0} {
                set ny [num $y]
                if {$ny eq "" || $ny % 2 == 0} { error "result is a complex number" }
                return [expr {-pow(-double($x), 1.0/$y)}]
            }
            return [chk [expr {pow(double($x), 1.0/$y)}]]
        }
        abs   { return [expr {abs($x)}] }
        sign - sgn { return [expr {$x > 0 ? 1 : ($x < 0 ? -1 : 0)}] }
        exp   { return [chk [expr {exp($x)}]] }
        ln {
            if {$x <= 0} { error "log of zero or a negative number" }
            return [expr {log($x)}]
        }
        log {
            if {$x <= 0} { error "log of zero or a negative number" }
            if {$n == 2} {
                if {$y <= 0 || $y == 1} { error "invalid log base" }
                return [expr {log($x) / log($y)}]
            }
            return [expr {log10($x)}]
        }
        log10 { if {$x <= 0} { error "log of zero or a negative number" }; return [expr {log10($x)}] }
        log2  { if {$x <= 0} { error "log of zero or a negative number" }; return [expr {log($x) / log(2.0)}] }
        sin   { return [clean [expr {sin($x)}]] }
        cos   { return [clean [expr {cos($x)}]] }
        tan   { return [clean [expr {tan($x)}]] }
        sec   { set c [clean [expr {cos($x)}]]; if {$c == 0} { error "undefined" }; return [expr {1.0/$c}] }
        csc   { set c [clean [expr {sin($x)}]]; if {$c == 0} { error "undefined" }; return [expr {1.0/$c}] }
        cot   { set c [clean [expr {tan($x)}]]; if {$c == 0} { error "undefined" }; return [clean [expr {1.0/$c}]] }
        asin  { if {abs($x) > 1} { error "asin() needs a value from -1 to 1" }; return [expr {asin($x)}] }
        acos  { if {abs($x) > 1} { error "acos() needs a value from -1 to 1" }; return [expr {acos($x)}] }
        atan  { return [expr {atan($x)}] }
        atan2 { return [expr {atan2($x, $y)}] }
        sind  { return [clean [expr {sin(fmod($x, 360) * $d2r)}]] }
        cosd  { return [clean [expr {cos(fmod($x, 360) * $d2r)}]] }
        tand  {
            set m [expr {fmod(abs($x), 180)}]
            if {$m == 90} { error "tan is undefined at 90 degrees" }
            return [clean [expr {tan(fmod($x, 360) * $d2r)}]]
        }
        asind { if {abs($x) > 1} { error "asind() needs a value from -1 to 1" }; return [expr {asin($x) / $d2r}] }
        acosd { if {abs($x) > 1} { error "acosd() needs a value from -1 to 1" }; return [expr {acos($x) / $d2r}] }
        atand { return [expr {atan($x) / $d2r}] }
        sinh  { return [chk [expr {sinh($x)}]] }
        cosh  { return [chk [expr {cosh($x)}]] }
        tanh  { return [expr {tanh($x)}] }
        asinh { return [expr {log($x + sqrt($x * $x + 1.0))}] }
        acosh { if {$x < 1} { error "acosh() needs a value of 1 or more" }; return [expr {log($x + sqrt($x * $x - 1.0))}] }
        atanh { if {abs($x) >= 1} { error "atanh() needs a value between -1 and 1" }; return [expr {0.5 * log((1.0 + $x) / (1.0 - $x))}] }
        floor { if {[isint $x]} { return $x }; return [expr {entier(floor($x))}] }
        ceil  { if {[isint $x]} { return $x }; return [expr {entier(ceil($x))}] }
        trunc - int { if {[isint $x]} { return $x }; return [expr {entier($x)}] }
        frac  { if {[isint $x]} { return 0 }; return [expr {$x - entier($x)}] }
        round {
            if {$n == 1} { if {[isint $x]} { return $x }; return [expr {round($x)}] }
            set p [needint $y "round()"]
            if {$p < 0 || $p > 15} { error "round() digits must be 0-15" }
            set m [expr {10.0 ** $p}]
            return [expr {round($x * $m) / $m}]
        }
        min   { return [tcl::mathfunc::min {*}$argv] }
        max   { return [tcl::mathfunc::max {*}$argv] }
        sum   { set s 0; foreach a $argv { set s [binop + $s $a] }; return $s }
        avg - mean { set s 0; foreach a $argv { set s [binop + $s $a] }; return [binop / $s $n] }
        median {
            set l [lsort -real $argv]
            set m [expr {$n / 2}]
            if {$n % 2} { return [lindex $l $m] }
            return [binop / [binop + [lindex $l [expr {$m - 1}]] [lindex $l $m]] 2]
        }
        hypot { set s 0.0; foreach a $argv { set s [expr {$s + double($a) * $a}] }; return [chk [expr {sqrt($s)}]] }
        pow   { return [binop ^ $x $y] }
        mod   { return [binop % $x $y] }
        fact - factorial { return [fn_fact $x] }
        ncr - comb - choose {
            set nn [needint $x "nCr()"]; set kk [needint $y "nCr()"]
            if {$kk < 0 || $nn < 0 || $kk > $nn} { return 0 }
            if {$nn > 100000} { error "number too large" }
            if {$kk > $nn - $kk} { set kk [expr {$nn - $kk}] }
            set r 1
            for {set i 1} {$i <= $kk} {incr i} { set r [expr {$r * ($nn - $kk + $i) / $i}] }
            return $r
        }
        npr - perm {
            set nn [needint $x "nPr()"]; set kk [needint $y "nPr()"]
            if {$kk < 0 || $nn < 0 || $kk > $nn} { return 0 }
            if {$nn > 100000} { error "number too large" }
            set r 1
            for {set i 0} {$i < $kk} {incr i} { set r [expr {$r * ($nn - $i)}] }
            return $r
        }
        gcd - lcm {
            set r [expr {abs([needint $x "${fn}()"])}]
            foreach a [lrange $argv 1 end] {
                set b [expr {abs([needint $a "${fn}()"])}]
                if {$fn eq "gcd"} {
                    while {$b != 0} { lassign [list $b [expr {$r % $b}]] r b }
                } else {
                    if {$r == 0 || $b == 0} { set r 0; continue }
                    set p $r; set q $b
                    while {$q != 0} { lassign [list $q [expr {$p % $q}]] p q }
                    set r [expr {$r / $p * $b}]
                }
            }
            return $r
        }
        deg   { return [expr {$x / $d2r}] }
        rad   { return [expr {$x * $d2r}] }
        rand {
            if {$n == 0} { return [expr {rand()}] }
            if {$n == 1} {
                set hiv [needint $x "rand()"]
                if {$hiv < 1} { error "rand(n) needs n of 1 or more" }
                return [expr {1 + entier(rand() * $hiv)}]
            }
            set a [needint $x "rand()"]; set b [needint $y "rand()"]
            if {$a > $b} { lassign [list $b $a] a b }
            return [expr {$a + entier(rand() * ($b - $a + 1))}]
        }
        isprime {
            set p [needint $x "isprime()"]
            if {$p > 1000000000000} { error "number too large to test" }
            if {$p < 2} { return 0 }
            if {$p < 4} { return 1 }
            if {$p % 2 == 0} { return 0 }
            for {set i 3} {$i * $i <= $p} {incr i 2} { if {$p % $i == 0} { return 0 } }
            return 1
        }
    }
    error "unknown function '$fn'"
}

###############################################################################
#  Evaluation, conversion, formatting
###############################################################################

proc ::calc::evalexpr {s} {
    variable T; variable P; variable D
    set s [string map [list \u00d7 * \u00f7 / \u2212 - \u03c0 pi \u2022 * \u00b7 *] $s]
    # "15% of 80"  ->  (15/100)*80
    regsub -all -nocase {([0-9.]+)\s*%\s*of\M} $s {(\1/100)*} s
    set T [tokenize $s]
    set P 0
    set D 0
    if {![llength $T]} { error "nothing to calculate" }
    set v [pexpr]
    set t [peek]
    if {$t ne ""} {
        if {[lindex $t 0] eq "rp"} { error "unmatched )" }
        error "unexpected '[lindex $t 1]'"
    }
    return [chk $v]
}

proc ::calc::fmt {v} {
    variable cfg
    if {[isint $v]} {
        set neg [expr {[string index $v 0] eq "-"}]
        set digits [string trimleft $v -]
        set len [string length $digits]
        if {$len <= $cfg(maxdigits)} { return $v }
        set mant "[string index $digits 0].[string range $digits 1 9]"
        set mant [string trimright [string trimright $mant 0] .]
        return "[expr {$neg ? {-} : {}}]${mant}e+[expr {$len - 1}] ($len digits)"
    }
    set s [format "%.$cfg(precision)g" $v]
    if {$s eq "-0"} { set s 0 }
    return $s
}

# Parse "100 inches" -> {100 length:in}
proc ::calc::parseqty {s} {
    set s [string trim $s]
    set n [string length $s]
    set lastErr ""
    for {set j 0} {$j < $n} {incr j} {
        set ch [string index $s $j]
        if {![regexp {[A-Za-z'\"\u00b0\u00b5\u03bc\u00c5]} $ch]} continue
        if {$j > 0 && ![regexp {[0-9.)\s]} [string index $s [expr {$j - 1}]]]} continue
        set ustr [string range $s $j end]
        set id [lookup $ustr]
        if {$id eq ""} continue
        set nstr [string trim [string range $s 0 [expr {$j - 1}]]]
        if {$nstr eq ""} { return [list 1 $id] }
        if {[catch {evalexpr $nstr} v]} { set lastErr $v; continue }
        return [list $v $id]
    }
    if {$lastErr ne ""} { error $lastErr }
    error "don't know the unit in '$s' (see: calc help units)"
}

proc ::calc::convert {val fid tid} {
    variable U; variable CATNAME
    lassign $U($fid) fcat fsym fname fkind ff fo
    lassign $U($tid) tcat tsym tname tkind tf to
    if {$fcat ne $tcat} {
        error "can't convert $CATNAME($fcat) ($fsym) to $CATNAME($tcat) ($tsym)"
    }
    set x [expr {double($val)}]
    if {$fkind eq "inv"} {
        if {$x == 0} { error "division by zero" }
        set base [expr {$ff / $x}]
    } else {
        set base [expr {$x * $ff + $fo}]
    }
    if {$tkind eq "inv"} {
        if {$base == 0} { error "division by zero" }
        set r [expr {$tf / $base}]
    } else {
        set r [expr {($base - $to) / $tf}]
    }
    return [chk $r]
}

# Returns {ok text value} or {err message} or {none}
proc ::calc::tryconvert {text} {
    set words [regexp -all -inline {\S+} $text]
    set n [llength $words]
    set err ""
    for {set i 1} {$i < $n - 1} {incr i} {
        if {[string tolower [lindex $words $i]] ni {in into to as -> =>}} continue
        set left  [join [lrange $words 0 [expr {$i - 1}]] " "]
        set right [join [lrange $words [expr {$i + 1}] end] " "]
        set rl [string tolower $right]

        # number base conversion
        set bases {hex 16 hexadecimal 16 bin 2 binary 2 oct 8 octal 8 dec 10 decimal 10}
        if {[dict exists $bases $rl]} {
            if {[catch {evalexpr $left} v]} { set err $v; continue }
            set iv [num $v]
            if {$iv eq ""} { return [list err "base conversion needs a whole number"] }
            switch -- [dict get $bases $rl] {
                16 { set out [expr {$iv < 0 ? "-" : ""}]0x[string toupper [format %llx [expr {abs($iv)}]]] }
                2  { set out [expr {$iv < 0 ? "-" : ""}]0b[format %llb [expr {abs($iv)}]] }
                8  { set out [expr {$iv < 0 ? "-" : ""}]0o[format %llo [expr {abs($iv)}]] }
                10 { set out $iv }
            }
            if {[string length $out] > 400} { return [list err "result too long to display"] }
            return [list ok "$left = $out" $iv]
        }

        set tid [lookup $right]
        if {$tid eq ""} { set err "unknown unit '$right' (see: calc help units)"; continue }
        if {[catch {parseqty $left} q]} { set err $q; continue }
        lassign $q v fid
        if {[catch {convert $v $fid $tid} r]} { return [list err $r] }
        variable U
        set fsym [lindex $U($fid) 1]
        set tsym [lindex $U($tid) 1]
        return [list ok "[fmt $v] $fsym = [fmt $r] $tsym" $r]
    }
    if {$err ne ""} { return [list err $err] }
    return [list none]
}

###############################################################################
#  Help
###############################################################################

proc ::calc::wrap {prefix items {max 380}} {
    set lines {}
    set line $prefix
    foreach it $items {
        if {[string length $line] + [string length $it] + 2 > $max && $line ne $prefix} {
            lappend lines [string trimright $line ", "]
            set line "   "
        }
        append line "$it, "
    }
    lappend lines [string trimright $line ", "]
    return $lines
}

proc ::calc::help {topic} {
    variable CATORDER; variable CATNAME; variable CATS; variable U; variable cfg
    set t [lindex $cfg(triggers) 0]
    set topic [string tolower [string trim $topic]]
    switch -glob -- $topic {
        "" {
            return [list \
                "\002Calculator help\002 - commands:" \
                "\002$t <math>\002 - calculate. Examples: $t 1+1 | $t (5+3)*2^10 | $t sqrt(144) | $t 5! | $t 15% of 80 | $t sind(30)" \
                "\002$t <number> <unit> in <unit>\002 - convert units. Examples: $t 100 inches in mm | $t 98.6 F to C | $t 5 kg to lb | $t 60 mph in km/h" \
                "\002$t <number> in hex|bin|oct|dec\002 - change number base. Examples: $t 255 in hex | $t 0xFF in dec | $t 10 in bin" \
                "\002$t help operators\002 - math operators (+ - * / ^ % !)" \
                "\002$t help functions\002 - math functions (sqrt, sin, log, round, nCr, gcd ...)" \
                "\002$t help constants\002 - constants (pi, e, c, g ...) and 'ans' (your last result)" \
                "\002$t help units\002 - list unit categories | \002$t help units <category>\002 - list every unit in a category (e.g. $t help units length)" \
                "\002$t help convert\002 - more about unit conversion" ]
        }
        op* {
            return [list \
                "\002Operators:\002 + add | - subtract | * multiply | / divide | ^ or ** power | % or mod remainder | ! factorial | ( ) grouping" \
                "Order: ( ) then ! then ^ (right to left) then * / % then + -. Implicit multiply works: 2pi, 3(4+5). 'X% of Y' gives a percentage: $t 15% of 80" \
                "Numbers: 1.5, .5, 1e6, 2.5e-3, 0xFF (hex), 0b1010 (binary), 0o17 (octal). Whole numbers are exact (big integers ok): $t 2^200" ]
        }
        func* {
            return [list \
                "\002Functions\002 (use parentheses, e.g. sqrt(16) or log(8,2)):" \
                "Roots/powers: sqrt(x) cbrt(x) root(x,n) pow(x,y) exp(x) | Logs: ln(x) log(x)=base 10 log(x,b)=base b log2(x) log10(x)" \
                "Trig (radians): sin cos tan sec csc cot asin acos atan atan2(y,x) | Trig (degrees): sind cosd tand asind acosd atand | Hyperbolic: sinh cosh tanh asinh acosh atanh" \
                "Rounding: round(x) round(x,digits) floor(x) ceil(x) trunc(x) frac(x) abs(x) sign(x) | Angles: deg(radians) rad(degrees)" \
                "Lists: min(a,b,..) max(..) sum(..) avg(..) median(..) hypot(..) | Integers: fact(n) or n! nCr(n,k) nPr(n,k) gcd(a,b,..) lcm(a,b,..) mod(a,b) isprime(n)" \
                "Random: rand() = 0 to 1 | rand(6) = 1 to 6 | rand(10,20) = 10 to 20" ]
        }
        const* {
            return [list \
                "\002Constants:\002 pi=3.14159.. | tau=2pi | e=2.71828.. | phi=1.61803.. (golden ratio) | c=299792458 (speed of light m/s) | g=9.80665 (gravity m/s^2)" \
                "G=6.6743e-11 (gravitational) | h=6.626e-34 (Planck) | k=1.381e-23 (Boltzmann) | NA=6.022e23 (Avogadro) | R=8.314 (gas) | qe (electron charge) | me (electron mass) | mp (proton mass)" \
                "\002ans\002 = your previous result, e.g. $t 12*12 then $t ans/2" ]
        }
        conv* {
            return [list \
                "\002Unit conversion:\002 $t <amount> <from unit> in <to unit>   ('to', 'into' and 'as' work too)" \
                "Units can be symbols, names or plurals: $t 100 inches in mm | $t 3 feet to cm | $t 2.5 square miles to acres | $t 10 cubic feet in gallons | $t 1 light year in km" \
                "The amount can be math: $t 2^10 MB in GB | $t (5+3) km to miles. Use 'per' or '/': $t 60 miles per hour in km/h" \
                "Temperature: $t 100 C to F | $t -40 F in C | $t 300 K to C   Fuel: $t 30 mpg to L/100km" \
                "Note: KB/MB/GB are 1000-based; KiB/MiB/GiB are 1024-based. Upper/lower case matters only where it changes meaning (Mb = megabit, MB = megabyte)." \
                "See all units: $t help units" ]
        }
        unit* {
            set rest [string trim [string range $topic [string length [lindex $topic 0]] end]]
            if {$rest eq ""} {
                set items {}
                foreach c $CATORDER { lappend items "$c ([llength $CATS($c)])" }
                return [concat \
                    [wrap "\002Unit categories\002 (number of units): " $items] \
                    [list "Type \002$t help units <category>\002 to list them, e.g. $t help units length"]]
            }
            set found ""
            foreach c $CATORDER {
                if {$c eq $rest || [string tolower $CATNAME($c)] eq $rest || [string match "$rest*" [string tolower $CATNAME($c)]] || [string match "$rest*" $c]} {
                    set found $c; break
                }
            }
            if {$found eq ""} {
                return [list "No unit category '$rest'. Categories: [join $CATORDER {, }]"]
            }
            set items {}
            foreach id $CATS($found) {
                lassign $U($id) c sym name
                if {$sym eq $name} { lappend items $sym } else { lappend items "$sym ($name)" }
            }
            return [wrap "\002$CATNAME($found)\002: " $items]
        }
        default {
            return [list "No help on '$topic'. Try: $t help | $t help operators | $t help functions | $t help constants | $t help units | $t help convert"]
        }
    }
}

###############################################################################
#  Main dispatcher - returns {say line} or {help lines}
###############################################################################

proc ::calc::process {nick text} {
    variable cfg; variable ANS; variable curnick
    set curnick $nick
    set text [string trim [regsub -all {[\x00-\x1f]} $text " "]]
    if {$text eq ""} {
        return [list say "Usage: [lindex $cfg(triggers) 0] <math or conversion>  e.g. [lindex $cfg(triggers) 0] 1+1  -  type [lindex $cfg(triggers) 0] help for more"]
    }
    set first [string tolower [lindex [split $text] 0]]
    if {$first in {help -h --help ?}} {
        return [list help [help [string range $text [string length $first] end]]]
    }
    if {$first eq "units"} {
        return [list help [help $text]]
    }
    if {[string length $text] > $cfg(maxlen)} {
        return [list say "Error: input too long"]
    }
    if {[catch {
        set c [tryconvert $text]
        switch -- [lindex $c 0] {
            ok {
                set ANS([string tolower $nick]) [lindex $c 2]
                set out [lindex $c 1]
            }
            err  { set out "Error: [lindex $c 1]" }
            none {
                set v [evalexpr $text]
                set ANS([string tolower $nick]) $v
                set out "$text = [fmt $v]"
            }
        }
    } msg]} {
        if {[string match "*too large*" $msg] || [string match "*out of range*" $msg]} {
            set msg "result is too large"
        } elseif {[string match "domain error*" $msg]} {
            set msg "math domain error (result undefined)"
        }
        set out "Error: $msg"
    }
    return [list say $out]
}

###############################################################################
#  Eggdrop bindings
###############################################################################

proc ::calc::throttled {uhost} {
    variable cfg; variable LAST
    if {$cfg(cooldown) <= 0} { return 0 }
    set now [clock seconds]
    if {[array size LAST] > 1000} { array unset LAST }
    if {[info exists LAST($uhost)] && $now - $LAST($uhost) < $cfg(cooldown)} { return 1 }
    set LAST($uhost) $now
    return 0
}

# Strip IRC colour/bold/underline codes (bridges often colour the names)
proc ::calc::stripcodes {s} {
    regsub -all {\003([0-9]{1,2}(,[0-9]{1,2})?)?|[\002\017\026\037\035\036]} $s "" s
    return $s
}

# Find a calc command in a channel line.
# Returns {who cmdtext atstart} or "" if the line has no calc command.
#   who      - the real person: the bridged name from "<name> ..." or the IRC nick
#   atstart  - 1 if the trigger was the first word (after any <name> prefix)
proc ::calc::extract {nick text} {
    variable cfg
    set text [string trim [stripcodes $text]]
    set who $nick
    # Bridge prefix:  <mro1337> calc 2*2
    if {[regexp {^<([^<>\s]{1,40})>\s*(.*)$} $text -> bname rest]} {
        set who [string trimleft $bname "@+%&~"]
        set text $rest
    }
    foreach trig $cfg(triggers) {
        set re [regsub -all {[][\\^$.|?*+(){}]} $trig {\\&}]
        # trigger as the first word
        if {[regexp -nocase "^${re}(?:\\s+(.*))?\$" $text -> cmd]} {
            return [list $who [string trim $cmd] 1]
        }
    }
    if {$cfg(anywhere)} {
        foreach trig $cfg(triggers) {
            set re [regsub -all {[][\\^$.|?*+(){}]} $trig {\\&}]
            # trigger anywhere in the line, followed by something to calculate
            if {[regexp -nocase "(?:^|\\s)${re}\\s+(\\S.*)\$" $text -> cmd]} {
                return [list $who [string trim $cmd] 0]
            }
        }
    }
    return ""
}

# Channel handler (pubm sees every line, so it also catches bridged messages)
proc ::calc::pubm {nick uhost hand chan text} {
    variable cfg
    set hit [extract $nick $text]
    if {$hit eq ""} { return 0 }
    lassign $hit who cmd atstart
    set bridged [expr {$who ne $nick}]
    # bridged users all share the bridge's host, so throttle them by name
    if {[throttled [expr {$bridged ? "$uhost/[string tolower $who]" : $uhost}]]} { return 0 }
    lassign [process $who $cmd] kind data
    if {!$atstart && $kind ne "help" && [string match "Error:*" $data]} {
        # mid-sentence: "can you calc 5 kg to lb for me" - drop trailing
        # words one at a time until what's left is a valid calculation
        set words [regexp -all -inline {\S+} $cmd]
        for {set i [expr {[llength $words] - 2}]} {$i >= 0} {incr i -1} {
            lassign [process $who [join [lrange $words 0 $i] " "]] k2 d2
            if {$k2 eq "say" && ![string match "Error:*" $d2]} {
                set data $d2
                break
            }
        }
    }
    if {$kind eq "help"} {
        foreach l $data {
            # a notice to the bridge would never reach the Telegram user
            if {$cfg(help_via) eq "channel" || $bridged} {
                puthelp "PRIVMSG $chan :$l"
            } else {
                puthelp "NOTICE $nick :$l"
            }
        }
    } else {
        # "calc" in the middle of ordinary chat: only answer if it worked
        if {!$atstart && ([string match "Error:*" $data] || [string match "Usage:*" $data])} {
            return 0
        }
        putserv "PRIVMSG $chan :$who: $data"
    }
    return 0
}

proc ::calc::msg {nick uhost hand text} {
    if {[throttled $uhost]} { return 0 }
    lassign [process $nick $text] kind data
    if {$kind eq "help"} {
        foreach l $data { puthelp "PRIVMSG $nick :$l" }
    } else {
        putserv "PRIVMSG $nick :$data"
    }
    return 0
}

if {[info commands putlog] ne ""} {
    # remove binds left over from older versions of this script
    foreach ::calc::b [binds] {
        if {[string match "::calc::*" [lindex $::calc::b 4]]} {
            catch { unbind [lindex $::calc::b 0] [lindex $::calc::b 1] [lindex $::calc::b 2] [lindex $::calc::b 4] }
        }
    }
    bind pubm - * ::calc::pubm
    foreach ::calc::trig $::calc::cfg(triggers) {
        bind msg - $::calc::trig ::calc::msg
    }
    unset -nocomplain ::calc::trig ::calc::b
    putlog "calc.tcl loaded - type '[lindex $::calc::cfg(triggers) 0] help' in a channel"
}
